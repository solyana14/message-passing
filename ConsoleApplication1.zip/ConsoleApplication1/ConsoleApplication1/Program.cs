﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Publisher dogPublisher = new Publisher();
            Publisher catPublisher = new Publisher();

            Subscriber AnimalLover = new Subscriber();
            Subscriber OldCatLady = new Subscriber();

            PubSubServer server = new PubSubServer();

            Message dogMessage = new Message();
            dogMessage.topic = "Dogs";
            dogMessage.payload = "Dogs are a mans best friend";

            Message catMessage = new Message();
            catMessage.topic = "Cats";
            catMessage.payload = "Cats can take care of themselves";

            dogPublisher.Send(dogMessage, server);
            catPublisher.Send(catMessage, server);

            AnimalLover.Listen("Dogs", 0);
            AnimalLover.Listen("Cats", 1);

            OldCatLady.Listen("Cats", 0);

            server.subscribers[0] = AnimalLover;
            server.subscribers[1] = OldCatLady;

            server.forward();

            Console.WriteLine("AnimalLover has subscribed to the following messages");
            AnimalLover.Print();
            Console.WriteLine("");
            Console.WriteLine("OldCatLady hahs subscribed to the following messages");
            OldCatLady.Print();
        }
    }
}
